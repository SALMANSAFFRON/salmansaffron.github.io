<?php
/*
Plugin Name: My Custom Discount
Description: Custom plugin to handle discounts based on external service.
*/

// Hook to add a custom discount to user's account balance
add_action('wp_loaded', 'add_custom_discount_to_balance');

// Function to add a custom discount to user's account balance
function add_custom_discount_to_balance() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $phone_number = '09361666015'; // Replace with user's phone number or get it from user meta
        
        //$discount = get_discount_from_external_service($phone_number);
        $discount = 1000;
        if ($discount !== false) {
            // Add the discount amount to user's balance
            $current_balance = get_user_meta($user_id, 'account_balance', true);
            $new_balance = $current_balance + $discount;
            update_user_meta($user_id, 'account_balance', $new_balance);
        }
    }
}

// Function to get discount from external service
function get_discount_from_external_service($phone_number) {
    $api_url = 'https://myservice.ir/user/credit/' . $phone_number;
    
    $response = wp_remote_get($api_url);
    
    if (is_wp_error($response)) {
        return false;
    }
    
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    
    if ($data && isset($data['discount'])) {
        return $data['discount'];
    } else {
        return false;
    }
}

// Hook to apply the discount to customer's invoice
add_action('woocommerce_before_calculate_totals', 'apply_custom_discount_to_invoice');

// Function to apply the discount to customer's invoice
function apply_custom_discount_to_invoice($cart) {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $discount = get_user_meta($user_id, 'account_balance', true);
        
        if ($discount > 0) {
            foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                // Apply the discount amount to cart items
                $cart_item['data']->set_price($cart_item['data']->get_price() - $discount);
            }
        }
    }
}

// Hook to display account balance in WooCommerce My Account page
add_action('woocommerce_account_dashboard', 'display_account_balance');

// Function to display account balance in WooCommerce My Account page
function display_account_balance() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $account_balance = get_user_meta($user_id, 'account_balance', true);
        
        if ($account_balance) {
            echo '<p>مانده بستانکار شما: ' . wc_price($account_balance) . '</p>';
        }
    }
}
